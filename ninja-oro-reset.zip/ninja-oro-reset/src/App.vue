<template>
  <div id="app">
    <p id="parrafo">Tu oro: {{oro}}</p>
    <Lugar nombrelugar="Granja" infolugar="(gana 10-20 oros)"/>
    <Lugar nombrelugar="Cueva" infolugar="(gana 5-10 oros)"/>
    <Lugar nombrelugar="Casa" infolugar="(gana 2-5 oros)"/>
    <Lugar nombrelugar="Casino" infolugar="(gana 0-50 oros)" />
    <div id="act">
      <ul>
        <li v-for="(item,index) in actividades" v-bind:key="index">{{item}}</li>  
      </ul>
    </div>
    <Reset />
  </div>
</template>

<script>
import Lugar from './components/Lugar.vue';
import Reset from './components/Reset.vue';
import almacen from "@/almacen";

export default {
  name: 'App',
  components: {
    Lugar,
    Reset,
  },
  data:function(){
     return almacen.state;
  },
}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  color: #2c3e50;
  margin-top: 60px;
}
#parrafo{
  margin:10px;
  font-size:20px;
}
#act{
  margin:10px;
  display:block;
  width:600px;
  min-height:200px;
  outline:3px solid black;
}
</style>
