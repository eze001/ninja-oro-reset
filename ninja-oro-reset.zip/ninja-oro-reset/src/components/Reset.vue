<template>
    <div id="creset">
        <button v-on:click="formateo">Reset</button>
        {{t1}}
    </div>
</template>


<script>
import Almacen from '@/almacen';

export default{
    data:function(){
        return{
            t1:"Precaución con apretar reset, perderas todos tus avances",
        };
    },
    methods:{
        formateo:function(){
            this.t1="";
            this.t1="Precaución con apretar reset, perderas todos tus avances";
        }
    },
    beforeUpdate(){
        var mensaje="Estas seguro de resetear el juego, perderas todos tus avances";
        var resultado = window.confirm(mensaje);
        if(resultado){
            Almacen.reseteo();
        }
    }
}
</script>


<style scoped>
    #creset{
        display:block;
    }
    button{
        margin:10px;
    }
</style>